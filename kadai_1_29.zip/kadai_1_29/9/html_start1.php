<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title><?=htmlEnc($title)?></title>
        
    </head>
    <body>
    
    
    
