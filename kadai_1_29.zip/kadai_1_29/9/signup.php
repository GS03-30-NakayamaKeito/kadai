<!DOCTYPE html>
<html lang="ja">
    <head>
       <nav></nav>
        <meta charset="utf-8">
        <title>ユーザー登録</title>
        <link href="" rel="">
        <style></style>
    </head>
    <body>
      <header>
          <nav>
           <p>新規登録</p>
          </nav>
           
      </header>
    　<div class="main-contens">
           <form method="post" action="insert1.php">
                <fieldset>
                    <legend>登録</legend>
                    <label>名前:<input type="text" name="name"></label><br>
                    <label>Email:<input type="text" name="email"></label><br>
                    <label>年齢:<input type="text" name="age"></label><br>
                    <label>パスワード:<input type="password" name="password"></label><br>
                    <input type="submit" value="送信">
                    
                </fieldset>
             
           </form>
           
    </div>
      
    </body>
    
    
</html>